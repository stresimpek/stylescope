import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import LandingPage from "./pages/LandingPage";
import HomepageSelesaiTest from "./pages/HomepageSelesaiTest";
import ScanTest from "./pages/ScanTest";
import TampilinResultTypesOfOut from "./pages/TampilinResultTypesOfOut";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/homepage-selesai-test":
        title = "";
        metaDescription = "";
        break;
      case "/scan-test":
        title = "";
        metaDescription = "";
        break;
      case "/tampilin-result-types-of-outfit-outfit-recommendation-detailnya-juga":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag: HTMLMetaElement | null = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/homepage-selesai-test" element={<HomepageSelesaiTest />} />
      <Route path="/scan-test" element={<ScanTest />} />
      <Route
        path="/tampilin-result-types-of-outfit-outfit-recommendation-detailnya-juga"
        element={<TampilinResultTypesOfOut />}
      />
    </Routes>
  );
}
export default App;
