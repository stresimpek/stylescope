import { FunctionComponent, useMemo, type CSSProperties } from "react";

export type AutoLayoutVerticalType = {
  className?: string;
  sCANNow?: string;

  /** Style props */
  propWidth?: CSSProperties["width"];
  propPadding?: CSSProperties["padding"];
};

const AutoLayoutVertical: FunctionComponent<AutoLayoutVerticalType> = ({
  className = "",
  sCANNow,
  propWidth,
  propPadding,
}) => {
  const autoLayoutVerticalStyle: CSSProperties = useMemo(() => {
    return {
      width: propWidth,
      padding: propPadding,
    };
  }, [propWidth, propPadding]);

  return (
    <div
      className={`flex flex-row items-start justify-start text-left text-3xl text-tan-100 font-inter ${className}`}
      style={autoLayoutVerticalStyle}
    >
      <div className="rounded-[5.05px] bg-txt flex flex-row items-start justify-start py-5 px-[37px] gap-[11.6px]">
        <div className="flex flex-col items-start justify-start pt-[1.5px] px-0 pb-0">
          <b className="h-[27px] relative tracking-[1px] uppercase font-semibold inline-block mq450:text-lg">
            {sCANNow}
          </b>
        </div>
        <img
          className="h-[30px] w-[30px] relative rounded-xl overflow-hidden shrink-0 object-contain min-h-[30px]"
          loading="lazy"
          alt=""
          src="/frame.svg"
        />
      </div>
    </div>
  );
};

export default AutoLayoutVertical;
