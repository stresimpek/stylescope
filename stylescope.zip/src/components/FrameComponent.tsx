import { FunctionComponent } from "react";

export type FrameComponentType = {
  className?: string;
};

const FrameComponent: FunctionComponent<FrameComponentType> = ({
  className = "",
}) => {
  return (
    <div
      className={`w-[788px] h-[853px] absolute !m-[0] top-[168px] right-[547px] bg-[url('/public/image-11@2x.png')] bg-cover bg-no-repeat bg-[top] z-[2] ${className}`}
    >
      <img
        className="absolute top-[0px] left-[0px] w-full h-full object-cover hidden"
        alt=""
        src="/image-11@2x.png"
      />
      <div className="absolute top-[-42px] right-[-16px] w-[809px] h-[895px]">
        <div className="absolute h-full top-[0px] bottom-[0px] left-[21px] w-[788px] bg-[url('/public/image-10@2x.png')] bg-cover bg-no-repeat bg-[top] z-[1]">
          <img
            className="absolute top-[0px] left-[0px] w-full h-full object-cover hidden"
            alt=""
            src="/image-10@2x.png"
          />
          <img
            className="absolute top-[362px] left-[670px] w-[110px] h-[116px] z-[3]"
            loading="lazy"
            alt=""
            src="/rectangle-402.svg"
          />
        </div>
        <img
          className="absolute top-[89px] left-[0px] w-[110px] h-[116px] z-[3]"
          loading="lazy"
          alt=""
          src="/rectangle-401.svg"
        />
      </div>
      <img
        className="absolute top-[103.8px] left-[104.7px] w-[134.3px] h-[46.2px] object-contain"
        loading="lazy"
        alt=""
        src="/line-14.svg"
      />
      <img
        className="absolute top-[355px] left-[458px] w-[227px] h-[22px] object-contain"
        loading="lazy"
        alt=""
      />
    </div>
  );
};

export default FrameComponent;
