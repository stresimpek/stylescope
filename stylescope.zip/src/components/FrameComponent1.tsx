import { FunctionComponent } from "react";

export type FrameComponent1Type = {
  className?: string;
};

const FrameComponent1: FunctionComponent<FrameComponent1Type> = ({
  className = "",
}) => {
  return (
    <section
      className={`self-stretch flex flex-row items-start justify-end pt-0 px-0 pb-[62px] box-border max-w-full text-center text-231xl text-txt font-le-murmure mq450:pb-10 mq450:box-border ${className}`}
    >
      <div className="w-[1489px] flex flex-row items-end justify-between py-0 pr-0 pl-5 box-border max-w-full gap-[20px] mq1350:flex-wrap">
        <img
          className="h-[148px] w-[150px] relative"
          loading="lazy"
          alt=""
          src="/starfilledwide.svg"
        />
        <div className="w-[790px] flex flex-col items-start justify-end pt-0 px-0 pb-[6.2px] box-border max-w-full">
          <div className="flex flex-row items-start justify-start py-0 pr-5 pl-0 box-border gap-[55px] max-w-full mq925:flex-wrap mq925:gap-[27px]">
            <div className="flex flex-row items-start justify-start [row-gap:20px] max-w-full mq925:flex-wrap">
              <h1 className="m-0 h-[264.3px] relative text-inherit font-normal font-inherit inline-block min-w-[381px] max-w-full mq450:text-43xl mq450:min-w-full mq925:text-81xl mq925:flex-1">
                About
              </h1>
              <div className="w-[146px] flex flex-col items-start justify-start pt-[2.8px] px-0 pb-0 box-border min-w-[146px] text-[transparent] mq925:flex-1">
                <h1 className="m-0 self-stretch h-[261.6px] relative text-inherit font-normal font-inherit inline-block [-webkit-text-stroke:3px_#fff] z-[1] mq450:text-43xl mq925:text-81xl">
                  Us
                </h1>
              </div>
            </div>
            <img
              className="h-[148px] w-[150px] relative"
              loading="lazy"
              alt=""
              src="/starfilledwide.svg"
            />
          </div>
        </div>
        <div className="w-[299px] flex flex-col items-start justify-end pt-0 px-0 pb-[18px] box-border">
          <div className="self-stretch h-[358px] relative">
            <img
              className="absolute top-[130px] left-[205px] w-[98.4px] h-[98.4px] object-contain"
              loading="lazy"
              alt=""
              src="/star-1.svg"
            />
            <div className="absolute h-full top-[0px] bottom-[0px] left-[0px] [filter:blur(205.3px)] rounded-[50%] bg-gray-500 w-[358px] z-[1]" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent1;
