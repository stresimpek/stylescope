import { FunctionComponent } from "react";
import AutoLayoutVertical from "./AutoLayoutVertical";

export type FrameComponent2Type = {
  className?: string;
};

const FrameComponent2: FunctionComponent<FrameComponent2Type> = ({
  className = "",
}) => {
  return (
    <section
      className={`w-[1895px] flex flex-row flex-wrap items-start justify-center py-0 pr-5 pl-0 box-border [row-gap:20px] max-w-full text-center text-481xl text-txt font-le-murmure ${className}`}
    >
      <div className="flex-1 flex flex-col items-start justify-start min-w-[602px] max-w-full mq925:min-w-full">
        <div className="self-stretch flex flex-row items-start justify-between max-w-full gap-[20px] mq925:flex-wrap">
          <img
            className="h-[148px] w-[150px] relative"
            loading="lazy"
            alt=""
            src="/starfilledwide.svg"
          />
          <div className="w-[617px] flex flex-col items-start justify-start pt-[92px] px-0 pb-0 box-border max-w-full mq925:pt-[60px] mq925:box-border">
            <h1 className="m-0 self-stretch h-[561px] relative text-inherit font-normal font-inherit whitespace-pre-wrap inline-block mq450:text-106xl mq925:text-181xl">{`style   `}</h1>
          </div>
        </div>
        <div className="w-[512px] flex flex-row items-start justify-center py-0 px-5 box-border max-w-full text-left text-3xl text-tan-100 font-inter">
          <AutoLayoutVertical sCANNow="SCAN Now" />
        </div>
      </div>
      <div className="w-[799px] flex flex-col items-start justify-start pt-[92px] px-0 pb-0 box-border max-w-full text-[transparent] mq925:pt-[60px] mq925:box-border">
        <h1 className="m-0 w-[724px] h-[561px] relative text-inherit font-normal font-inherit inline-block [-webkit-text-stroke:3px_#fff] max-w-full mq450:text-106xl mq925:text-181xl">
          scope
        </h1>
      </div>
      <div className="flex flex-col items-start justify-start pt-[660px] px-0 pb-0 mq450:pt-[279px] mq450:box-border mq925:pt-[429px] mq925:box-border">
        <img
          className="w-[150px] h-[148px] relative"
          loading="lazy"
          alt=""
          src="/starfilledwide.svg"
        />
      </div>
    </section>
  );
};

export default FrameComponent2;
