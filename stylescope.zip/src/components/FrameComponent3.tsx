import { FunctionComponent } from "react";
import AutoLayoutVertical from "./AutoLayoutVertical";

export type FrameComponent3Type = {
  className?: string;
};

const FrameComponent3: FunctionComponent<FrameComponent3Type> = ({
  className = "",
}) => {
  return (
    <div
      className={`self-stretch flex flex-row items-start justify-center py-0 pr-5 pl-[27px] box-border max-w-full ${className}`}
    >
      <div className="w-[1425px] flex flex-col items-end justify-start gap-[22px] max-w-full">
        <div className="self-stretch h-[103px] relative">
          <div className="absolute top-[45px] left-[26px] bg-txt w-[1347px] h-[13px]" />
          <div className="absolute h-full top-[0px] bottom-[0px] left-[0px] shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-[50%] bg-tan-200 w-[106px] z-[1]" />
          <div className="absolute h-full top-[0px] bottom-[0px] left-[438px] shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-[50%] bg-antiquewhite-100 w-[106px] z-[1]" />
          <div className="absolute h-full top-[0px] bottom-[0px] left-[875px] shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-[50%] bg-antiquewhite-100 w-[106px] z-[1]" />
          <div className="absolute h-full top-[0px] bottom-[0px] left-[1319px] shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] rounded-[50%] bg-antiquewhite-100 w-[106px] z-[1]" />
        </div>
        <AutoLayoutVertical
          sCANNow="Done Scan"
          propWidth="1414px"
          propPadding="0px 20px"
        />
      </div>
    </div>
  );
};

export default FrameComponent3;
