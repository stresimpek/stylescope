import { FunctionComponent } from "react";
import FrameComponent5 from "./FrameComponent5";

export type FrameComponent4Type = {
  className?: string;
};

const FrameComponent4: FunctionComponent<FrameComponent4Type> = ({
  className = "",
}) => {
  return (
    <div
      className={`self-stretch grid flex-row items-end justify-start gap-[75.7px] max-w-full grid-cols-[repeat(4,_minmax(271px,_1fr))] text-center text-9xl text-txt font-h6 mq825:gap-[38px] mq825:grid-cols-[minmax(271px,_1fr)] mq1400:justify-center mq1400:grid-cols-[repeat(2,_minmax(271px,_470px))] mq450:gap-[19px] ${className}`}
    >
      <FrameComponent5
        maskGroup="/mask-group-3@2x.png"
        maskGroup1="/mask-group-5.svg"
        skinColor="Skin Color"
        uploadAPhotoToScanYourSki="Upload a photo to scan your skin color."
        seeDetail="Scan  Now"
      />
      <FrameComponent5
        maskGroup="/mask-group-21.svg"
        maskGroup1="pending_38:1021"
        skinColor="Body Shape"
        uploadAPhotoToScanYourSki="Upload a photo to scan your body shape."
        seeDetail="Scan Now"
        propMinWidth="105px"
      />
      <div className="flex flex-col items-start justify-start pt-[85px] px-[39px] pb-[70px] box-border relative gap-[84px] max-w-full mq450:gap-[42px] mq450:pt-[55px] mq450:pb-[45px] mq450:box-border">
        <img
          className="w-full h-full absolute !m-[0] top-[0px] right-[0px] bottom-[0px] left-[0px] max-w-full overflow-hidden max-h-full"
          loading="lazy"
          alt=""
          src="/mask-group-5.svg"
        />
        <div className="self-stretch flex flex-col items-start justify-start gap-[19px]">
          <div className="self-stretch flex flex-row items-start justify-start py-0 px-[73px] mq450:pl-5 mq450:pr-5 mq450:box-border">
            <b className="relative font-bold z-[1] mq450:text-3xl">
              Hair Color
            </b>
          </div>
          <p className="m-0 self-stretch relative text-lg font-body1-light z-[1]">
            Upload a photo to scan your hair color.
          </p>
        </div>
        <div className="self-stretch flex flex-row items-start justify-start py-0 pr-[50px] pl-12 mq450:pl-5 mq450:pr-5 mq450:box-border">
          <button className="cursor-pointer [border:none] py-2.5 px-10 bg-color flex-1 rounded-11xl flex flex-row items-start justify-start whitespace-nowrap z-[1] hover:bg-chocolate">
            <b className="relative text-3xl font-bold font-h6 text-txt text-left inline-block min-w-[105px]">
              Scan Now
            </b>
          </button>
        </div>
      </div>
      <div className="flex flex-col items-end justify-start pt-[87px] px-[39px] pb-[68px] box-border relative gap-[84px] max-w-full mq450:gap-[42px] mq450:pt-[57px] mq450:pb-11 mq450:box-border">
        <img
          className="w-full h-full absolute !m-[0] top-[0px] right-[0px] bottom-[0px] left-[0px] max-w-full overflow-hidden max-h-full"
          loading="lazy"
          alt=""
          src="/mask-group-5.svg"
        />
        <div className="self-stretch flex flex-col items-start justify-start gap-[19px]">
          <div className="self-stretch flex flex-row items-start justify-start py-0 px-[68px] mq450:pl-5 mq450:pr-5 mq450:box-border">
            <b className="relative z-[1] mq450:text-3xl">Undertone</b>
          </div>
          <p className="m-0 self-stretch relative text-lg font-body1-light z-[1]">
            Upload a photo to scan your undertone.
          </p>
        </div>
        <div className="flex flex-row items-start justify-end py-0 px-[41px]">
          <button className="cursor-pointer [border:none] py-2.5 px-10 bg-color rounded-11xl flex flex-row items-start justify-start whitespace-nowrap z-[1] hover:bg-chocolate">
            <b className="relative text-3xl inline-block font-h6 text-txt text-left min-w-[105px]">
              Scan Now
            </b>
          </button>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent4;
