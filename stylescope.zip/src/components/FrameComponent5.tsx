import { FunctionComponent, useMemo, type CSSProperties } from "react";

export type FrameComponent5Type = {
  className?: string;
  maskGroup?: string;
  maskGroup1?: string;
  skinColor?: string;
  uploadAPhotoToScanYourSki?: string;
  seeDetail?: string;

  /** Style props */
  propMinWidth?: CSSProperties["minWidth"];
};

const FrameComponent5: FunctionComponent<FrameComponent5Type> = ({
  className = "",
  maskGroup,
  maskGroup1,
  skinColor,
  uploadAPhotoToScanYourSki,
  seeDetail,
  propMinWidth,
}) => {
  const seeDetailStyle: CSSProperties = useMemo(() => {
    return {
      minWidth: propMinWidth,
    };
  }, [propMinWidth]);

  return (
    <div
      className={`flex flex-col items-start justify-end pt-0 px-0 pb-1 box-border max-w-full text-center text-9xl text-txt font-h6 ${className}`}
    >
      <div className="self-stretch flex flex-col items-end justify-start pt-[89px] px-[39px] pb-[81px] relative gap-[69px] mq450:gap-[34px] mq450:pt-[58px] mq450:pb-[53px] mq450:box-border">
        <img
          className="w-full h-full absolute !m-[0] right-[0px] bottom-[-2px] left-[0px] max-w-full overflow-hidden shrink-0 object-cover"
          alt=""
          src={maskGroup}
        />
        <img
          className="w-full h-full absolute !m-[0] top-[0px] right-[0px] bottom-[0px] left-[0px] max-w-full overflow-hidden max-h-full z-[1]"
          loading="lazy"
          alt=""
          src={maskGroup1}
        />
        <div className="self-stretch flex flex-col items-start justify-start gap-[19px]">
          <div className="self-stretch flex flex-row items-start justify-start py-0 px-[72px] mq450:pl-5 mq450:pr-5 mq450:box-border">
            <b className="relative font-bold z-[2] mq450:text-3xl">
              {skinColor}
            </b>
          </div>
          <p className="m-0 self-stretch relative text-lg font-body1-light z-[2]">
            {uploadAPhotoToScanYourSki}
          </p>
        </div>
        <div className="self-stretch flex flex-row items-start justify-end py-0 pr-[46px] pl-12 mq450:pl-5 mq450:pr-5 mq450:box-border">
          <button className="cursor-pointer [border:none] py-2.5 px-10 bg-color flex-1 rounded-11xl flex flex-row items-start justify-start whitespace-nowrap z-[2] hover:bg-chocolate">
            <b
              className="relative text-3xl font-bold font-h6 text-txt whitespace-pre-wrap text-left inline-block min-w-[109px]"
              style={seeDetailStyle}
            >
              {seeDetail}
            </b>
          </button>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent5;
