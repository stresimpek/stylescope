import { FunctionComponent } from "react";

export type FrameComponent6Type = {
  className?: string;
};

const FrameComponent6: FunctionComponent<FrameComponent6Type> = ({
  className = "",
}) => {
  return (
    <section
      className={`w-[1862px] flex flex-row items-start justify-center py-0 px-5 box-border max-w-full text-left text-mid text-txt font-body1-light ${className}`}
    >
      <div className="w-[1184px] flex flex-col items-start justify-start gap-[117px] max-w-full mq950:gap-[29px] mq1425:gap-[58px]">
        <div className="self-stretch flex flex-row items-start justify-start py-0 pr-7 pl-[27px] box-border max-w-full">
          <div className="flex-1 flex flex-row items-start justify-start gap-[97px] max-w-full mq950:gap-[24px] mq1425:flex-wrap mq1425:gap-[48px]">
            <div className="flex-1 flex flex-col items-start justify-start pt-[41px] px-0 pb-0 box-border min-w-[348px] max-w-full mq450:pt-[27px] mq450:box-border mq950:min-w-full">
              <div className="self-stretch flex flex-col items-start justify-start gap-[45px] max-w-full mq950:gap-[22px]">
                <div className="relative text-11xl font-medium inline-block max-w-full mq450:text-lg mq950:text-5xl">
                  <p className="m-0">{`Lorem Ipsum is simply dummy `}</p>
                  <p className="m-0">{`text dummy text `}</p>
                </div>
                <p className="m-0 self-stretch relative">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard dummy text ever since the 1500s, when an unknown
                  printer took a galley of type and scrambled it to make a type
                  specimen book. It has survived not only five centuries,
                </p>
                <p className="m-0 w-[508px] h-[58px] relative inline-block shrink-0 max-w-full">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. `}</p>
              </div>
            </div>
            <img
              className="w-[496.3px] relative max-h-full object-cover max-w-full mq1425:flex-1"
              loading="lazy"
              alt=""
              src="/mask-group-22@2x.png"
            />
          </div>
        </div>
        <div className="self-stretch flex flex-row items-end justify-start gap-[156px] max-w-full mq450:gap-[19px] mq950:gap-[39px] mq1425:flex-wrap mq1425:gap-[78px]">
          <img
            className="w-[492px] relative max-h-full object-cover max-w-full mq1425:flex-1"
            loading="lazy"
            alt=""
            src="/mask-group-31@2x.png"
          />
          <div className="flex-1 flex flex-col items-start justify-start pt-0 px-0 pb-[54px] box-border min-w-[348px] min-h-[422px] max-w-full mq450:pb-[35px] mq450:box-border mq450:min-w-full">
            <div className="self-stretch flex flex-col items-start justify-start gap-[45px] max-w-full mq950:gap-[22px]">
              <div className="relative text-11xl font-medium inline-block max-w-full mq450:text-lg mq950:text-5xl">
                <p className="m-0">{`Lorem Ipsum is simply dummy `}</p>
                <p className="m-0">{`text dummy text `}</p>
              </div>
              <p className="m-0 self-stretch relative">
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type specimen book. It has
                survived not only five centuries,
              </p>
              <p className="m-0 w-[508px] h-[58px] relative inline-block shrink-0 max-w-full">{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. `}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent6;
