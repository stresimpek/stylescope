import { FunctionComponent } from "react";

export type FrameComponent7Type = {
  className?: string;
};

const FrameComponent7: FunctionComponent<FrameComponent7Type> = ({
  className = "",
}) => {
  return (
    <section
      className={`w-[1862px] flex flex-row items-start justify-center pt-0 px-5 pb-[181px] box-border max-w-full text-left text-15xl text-txt font-body1-light mq950:pb-[118px] mq950:box-border ${className}`}
    >
      <div className="w-[1184px] flex flex-col items-start justify-start gap-[0.7px] max-w-full">
        <div className="self-stretch flex flex-row items-start justify-center py-0 pr-5 pl-[523px] mq950:pl-[130px] mq950:box-border">
          <div className="h-[24.3px] relative font-medium inline-block mq450:text-xl mq950:text-8xl">
            Your body type is Pear
          </div>
        </div>
        <div className="self-stretch flex flex-row items-start justify-center gap-[149px] max-w-full text-xl mq450:gap-[19px] mq950:gap-[37px] mq1425:flex-wrap mq1425:gap-[74px]">
          <img
            className="w-[499px] relative max-h-full object-cover max-w-full mq1425:flex-1"
            loading="lazy"
            alt=""
            src="/mask-group-11@2x.png"
          />
          <div className="flex-1 flex flex-col items-start justify-start pt-[50.3px] px-0 pb-0 box-border min-w-[348px] max-w-full mq450:min-w-full">
            <p className="m-0 self-stretch h-[75.7px] relative inline-block shrink-0 mq450:text-base">
              <span className="block">Recommended:</span>
              <ol className="m-0 font-inherit text-inherit pl-[27px]">
                <li className="mb-0">
                  Layered Look: Combine neutral tones in a shirt, sweater, and
                  jeans.
                </li>
                <li className="mb-0">
                  Structured Jackets: Opt for earthy-toned blazers or coats.
                </li>
                <li className="mb-0">
                  Textured Fabrics: Experiment with tweed or corduroy for added
                  depth.
                </li>
                <li className="mb-0">
                  Accessories: Complete your look with subtle-toned belts and
                  scarves.
                </li>
              </ol>
              <span className="block">&nbsp;</span>
              <span className="block">Fashion to Avoid:</span>
              <ol className="m-0 font-inherit text-inherit pl-[27px]">
                <li className="mb-0">Neon Colors: Avoid flashy hues.</li>
                <li className="mb-0">
                  Bright Colors: Steer clear of overly vivid shades.
                </li>
                <li className="mb-0">
                  Pale Shades: Skip colors that wash out your complexion.
                </li>
                <li>
                  Overly Dark Shades: Balance dark colors with lighter accents.
                </li>
              </ol>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent7;
