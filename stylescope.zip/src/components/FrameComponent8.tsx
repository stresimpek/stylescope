import { FunctionComponent } from "react";

export type FrameComponent8Type = {
  className?: string;
};

const FrameComponent8: FunctionComponent<FrameComponent8Type> = ({
  className = "",
}) => {
  return (
    <section
      className={`self-stretch flex flex-row items-start justify-start py-0 pr-[462px] pl-[468px] box-border gap-[267px] max-w-full text-center text-181xl text-txt font-le-murmure mq450:gap-[33px] mq450:pl-5 mq450:pr-5 mq450:box-border mq950:gap-[67px] mq950:pl-[117px] mq950:pr-[115px] mq950:box-border mq1425:gap-[133px] mq1425:pl-[234px] mq1425:pr-[231px] mq1425:box-border mq1900:flex-wrap mq1900:justify-center ${className}`}
    >
      <div className="ml-[-625px] h-[358px] w-[358px] relative [filter:blur(205.3px)] rounded-[50%] bg-gray-400 min-w-[358px] shrink-0 [debug_commit:bf4bc93] max-w-full mq1425:min-w-full mq1900:flex-1" />
      <div className="flex flex-col items-start justify-start pt-[37.3px] px-0 pb-0 box-border min-w-[990px] max-w-full mq450:min-w-full mq950:min-w-full mq1425:min-w-full mq1900:flex-1 mq1900:min-w-full">
        <div className="flex flex-row items-start justify-start gap-[67px] shrink-0 [debug_commit:bf4bc93] max-w-full mq950:gap-[17px] mq1425:flex-wrap mq1425:gap-[33px]">
          <div className="h-[201.7px] w-[132px] flex flex-col items-start justify-start pt-[77.7px] px-0 pb-0 box-border">
            <img
              className="self-stretch flex-1 relative max-w-full overflow-hidden max-h-full"
              loading="lazy"
              alt=""
              src="/starfilledwide-2.svg"
            />
          </div>
          <div className="w-[592px] flex flex-row items-start justify-start py-0 pr-6 pl-0 box-border [row-gap:20px] max-w-full mq950:flex-wrap">
            <div className="w-[229px] flex flex-col items-start justify-start pt-[28.8px] px-0 pb-0 box-border min-w-[229px] mq950:flex-1">
              <h1 className="m-0 self-stretch h-[209.1px] relative text-inherit font-normal font-inherit whitespace-pre-wrap inline-block mq450:text-31xl mq950:text-61xl">{`your    `}</h1>
            </div>
            <h1 className="m-0 h-[211.4px] flex-1 relative text-inherit font-normal font-inherit text-[transparent] inline-block [-webkit-text-stroke:3px_#fff] min-w-[220px] max-w-full mq450:text-31xl mq950:text-61xl">
              {" "}
              result
            </h1>
          </div>
          <div className="h-[139.7px] w-[132px] flex flex-col items-start justify-start pt-[15.7px] px-0 pb-0 box-border">
            <img
              className="self-stretch flex-1 relative max-w-full overflow-hidden max-h-full"
              loading="lazy"
              alt=""
              src="/starfilledwide-2.svg"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent8;
