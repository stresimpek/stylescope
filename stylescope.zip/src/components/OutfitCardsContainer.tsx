import { FunctionComponent, useMemo, type CSSProperties } from "react";

export type OutfitCardsContainerType = {
  className?: string;
  outfitCardBackgrounds?: string;
  blueDress?: string;
  arrow1?: string;

  /** Style props */
  propWidth?: CSSProperties["width"];
  propGap?: CSSProperties["gap"];
  propWidth1?: CSSProperties["width"];
  propAlignSelf?: CSSProperties["alignSelf"];
  propWidth2?: CSSProperties["width"];
};

const OutfitCardsContainer: FunctionComponent<OutfitCardsContainerType> = ({
  className = "",
  outfitCardBackgrounds,
  blueDress,
  arrow1,
  propWidth,
  propGap,
  propWidth1,
  propAlignSelf,
  propWidth2,
}) => {
  const outfitCardsContainerStyle: CSSProperties = useMemo(() => {
    return {
      width: propWidth,
      gap: propGap,
    };
  }, [propWidth, propGap]);

  const outfitCardDescriptionsStyle: CSSProperties = useMemo(() => {
    return {
      width: propWidth1,
    };
  }, [propWidth1]);

  const blueDressStyle: CSSProperties = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
    };
  }, [propAlignSelf]);

  const exploreNowStyle: CSSProperties = useMemo(() => {
    return {
      width: propWidth2,
    };
  }, [propWidth2]);

  return (
    <div
      className={`w-[484px] flex flex-col items-start justify-start gap-[28px] max-w-full text-left text-13xl text-gray-200 font-body1-light ${className}`}
      style={outfitCardsContainerStyle}
    >
      <img
        className="self-stretch h-[704px] relative rounded-xl max-w-full overflow-hidden shrink-0 object-cover"
        loading="lazy"
        alt=""
        src={outfitCardBackgrounds}
      />
      <div className="self-stretch flex flex-row items-center justify-between max-w-full gap-[20px] mq450:flex-wrap">
        <div
          className="w-[321px] flex flex-col items-start justify-start gap-[7px] max-w-full"
          style={outfitCardDescriptionsStyle}
        >
          <div
            className="self-stretch relative tracking-[-0.04em] leading-[36px] font-medium mq950:text-7xl mq950:leading-[29px] mq450:text-lgi mq450:leading-[22px]"
            style={blueDressStyle}
          >
            {blueDress}
          </div>
          <div
            className="w-[151px] h-[33px] relative text-5xl tracking-[-0.04em] leading-[50px] font-medium text-gray-100 inline-block shrink-0 mq450:text-lgi mq450:leading-[40px]"
            style={exploreNowStyle}
          >
            Explore Now!
          </div>
        </div>
        <img
          className="h-[22.1px] w-8 relative"
          loading="lazy"
          alt=""
          src={arrow1}
        />
      </div>
    </div>
  );
};

export default OutfitCardsContainer;
