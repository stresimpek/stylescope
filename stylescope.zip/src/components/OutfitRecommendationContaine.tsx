import { FunctionComponent } from "react";
import OutfitCardsContainer from "./OutfitCardsContainer";

export type OutfitRecommendationContaineType = {
  className?: string;
};

const OutfitRecommendationContaine: FunctionComponent<
  OutfitRecommendationContaineType
> = ({ className = "" }) => {
  return (
    <section
      className={`w-[1892px] flex flex-row items-start justify-center py-0 px-5 box-border max-w-full text-center text-181xl text-txt font-le-murmure ${className}`}
    >
      <div className="w-[1638px] flex flex-col items-start justify-start gap-[79px] max-w-full mq450:gap-[20px] mq700:gap-[39px]">
        <div className="self-stretch flex flex-row items-start justify-center py-0 px-5 box-border max-w-full">
          <div className="w-[1252px] flex flex-row flex-wrap items-start justify-start max-w-full [row-gap:20px]">
            <h1 className="m-0 h-56 w-[297px] relative text-inherit font-normal font-inherit whitespace-pre-wrap inline-block z-[4] mq950:text-61xl mq450:text-31xl">{`Outfit    `}</h1>
            <h1 className="m-0 h-56 flex-1 relative text-inherit font-normal font-inherit text-[transparent] inline-block [-webkit-text-stroke:3px_#fff] min-w-[621px] max-w-full z-[5] mq950:text-61xl mq950:min-w-full mq450:text-31xl">
              {" "}
              Recommendations
            </h1>
          </div>
        </div>
        <div className="self-stretch flex flex-row flex-wrap items-start justify-start gap-[118px_88px] min-h-[1734px] max-w-full text-left text-13xl text-gray-200 font-body1-light mq450:gap-[22px] mq700:gap-[44px]">
          <OutfitCardsContainer
            outfitCardBackgrounds="/rectangle-20@2x.png"
            blueDress="Blue dress"
            arrow1="/arrow-1.svg"
          />
          <OutfitCardsContainer
            outfitCardBackgrounds="/rectangle-21@2x.png"
            blueDress={`Blue dress & outer`}
            arrow1="/arrow-2.svg"
            propWidth="484px"
            propGap="26px"
            propWidth1="285px"
            propAlignSelf="stretch"
            propWidth2="153px"
          />
          <OutfitCardsContainer
            outfitCardBackgrounds="/rectangle-22@2x.png"
            blueDress="Layered Outfit"
            arrow1="/arrow-2.svg"
            propWidth="490px"
            propGap="24px"
            propWidth1="unset"
            propAlignSelf="unset"
            propWidth2="unset"
          />
          <OutfitCardsContainer
            outfitCardBackgrounds="/rectangle-20@2x.png"
            blueDress="Blue dress"
            arrow1="/arrow-1.svg"
            propWidth="484px"
            propGap="28px"
            propWidth1="321px"
            propAlignSelf="stretch"
            propWidth2="151px"
          />
          <OutfitCardsContainer
            outfitCardBackgrounds="/rectangle-21@2x.png"
            blueDress={`Blue dress & outer`}
            arrow1="/arrow-2.svg"
            propWidth="484px"
            propGap="26px"
            propWidth1="285px"
            propAlignSelf="stretch"
            propWidth2="153px"
          />
          <OutfitCardsContainer
            outfitCardBackgrounds="/rectangle-22@2x.png"
            blueDress="Layered Outfit"
            arrow1="/arrow-2.svg"
            propWidth="490px"
            propGap="24px"
            propWidth1="unset"
            propAlignSelf="unset"
            propWidth2="unset"
          />
        </div>
      </div>
    </section>
  );
};

export default OutfitRecommendationContaine;
