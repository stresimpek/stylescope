import { FunctionComponent } from "react";

export type RatingStarsType = {
  className?: string;
};

const RatingStars: FunctionComponent<RatingStarsType> = ({
  className = "",
}) => {
  return (
    <div
      className={`self-stretch flex flex-row items-start justify-start relative max-w-full text-center text-9xl text-txt font-le-murmure ${className}`}
    >
      <img
        className="h-[148px] w-[150px] absolute !m-[0] right-[45px] bottom-[795px]"
        loading="lazy"
        alt=""
        src="/starfilledwide.svg"
      />
      <img
        className="h-[148px] w-[150px] absolute !m-[0] top-[173px] left-[0px]"
        alt=""
        src="/starfilledwide.svg"
      />
      <div className="h-px w-[1721px] absolute !m-[0] top-[102px] left-[calc(50%_-_860px)] box-border z-[1] border-t-[1px] border-solid border-txt" />
      <h1 className="!m-[0] h-[561px] w-[617px] absolute top-[265px] left-[309px] text-481xl font-normal font-inherit whitespace-pre-wrap inline-block z-[1] mq950:text-181xl mq450:text-106xl">{`style   `}</h1>
      <h1 className="!m-[0] h-[561px] w-[724px] absolute top-[265px] right-[270px] text-481xl font-normal font-inherit text-[transparent] inline-block [-webkit-text-stroke:3px_#fff] z-[1] mq950:text-181xl mq450:text-106xl">
        scope
      </h1>
      <div className="!m-[0] absolute top-[826px] left-[150px] flex flex-row items-start justify-start text-left text-3xl text-tan-100 font-inter">
        <div className="rounded-[5.05px] bg-txt flex flex-row items-start justify-start py-5 px-[37px] gap-[11.6px]">
          <div className="flex flex-col items-start justify-start pt-[1.5px] px-0 pb-0">
            <b className="h-[27px] relative tracking-[1px] uppercase font-semibold inline-block mq450:text-lg">
              SCAN Now
            </b>
          </div>
          <img
            className="h-[30px] w-[30px] relative rounded-xl overflow-hidden shrink-0 object-contain min-h-[30px]"
            loading="lazy"
            alt=""
            src="/frame.svg"
          />
        </div>
      </div>
      <h1 className="!m-[0] h-[258px] w-[263px] absolute bottom-[449px] left-[622px] text-211xl font-normal font-inherit whitespace-pre-wrap inline-block z-[4] mq950:text-73xl mq450:text-38xl">{`your    `}</h1>
      <div className="h-[1281px] w-[788px] absolute !m-[0] top-[88px] right-[540px] text-211xl text-[transparent]">
        <img
          className="absolute top-[0px] left-[0px] w-[788px] h-[1236px] object-cover"
          alt=""
          src="/image-10@2x.png"
        />
        <h1 className="m-0 absolute top-[1023px] left-[293px] text-inherit font-normal font-inherit [-webkit-text-stroke:3px_#fff] z-[5] mq950:text-73xl mq450:text-38xl">
          {" "}
          result
        </h1>
      </div>
      <img
        className="h-[124px] w-[132px] absolute !m-[0] bottom-[508px] left-[442px] z-[4]"
        alt=""
        src="/starfilledwide-2.svg"
      />
      <img
        className="h-[124px] w-[132px] absolute !m-[0] right-[465px] bottom-[570px] z-[4]"
        alt=""
        src="/starfilledwide-2.svg"
      />
      <div className="w-[361.3px] !m-[0] absolute bottom-[2px] left-[561px] flex flex-col items-end justify-start pt-[89px] px-[39px] pb-[71px] box-border gap-[79px] font-h6">
        <img
          className="w-full h-full absolute !m-[0] top-[0px] right-[0px] bottom-[0px] left-[0px] max-w-full overflow-hidden max-h-full z-[6]"
          alt=""
        />
        <div className="self-stretch flex flex-col items-start justify-start gap-[19px]">
          <div className="flex flex-row items-start justify-start py-0 px-[61px]">
            <b className="relative z-[7] mq450:text-3xl">Body Shape</b>
          </div>
          <p className="m-0 self-stretch relative text-lg font-body1-light z-[7]">
            Lorem ipsum dolor sit amet consectetur Convallis est
          </p>
        </div>
        <div className="flex flex-row items-start justify-end py-0 pr-[27px] pl-7">
          <button className="cursor-pointer [border:none] py-2.5 px-10 bg-color rounded-11xl flex flex-row items-start justify-start whitespace-nowrap z-[7] hover:bg-chocolate">
            <b className="relative text-3xl font-h6 text-txt text-left">
              Check Details
            </b>
          </button>
        </div>
      </div>
      <div className="w-[361.3px] !m-[0] absolute right-[560.7px] bottom-[0px] flex flex-col items-end justify-start pt-[87px] px-[39px] pb-[73px] box-border gap-[81px] font-h6">
        <div className="w-full h-full absolute !m-[0] top-[0px] right-[0px] bottom-[0px] left-[0px]">
          <img
            className="absolute h-full w-full top-[0px] right-[0px] bottom-[2px] left-[0px] max-w-full overflow-hidden max-h-full object-cover z-[4]"
            alt=""
            src="/mask-group-1@2x.png"
          />
          <img
            className="absolute h-full w-full top-[0px] right-[0px] bottom-[0px] left-[0px] max-w-full overflow-hidden max-h-full z-[5]"
            alt=""
            src="/mask-group-2.svg"
          />
        </div>
        <div className="self-stretch flex flex-col items-start justify-start gap-[19px]">
          <div className="flex flex-row items-start justify-start py-0 px-[73px]">
            <b className="relative z-[6] mq450:text-3xl">Hair Color</b>
          </div>
          <p className="m-0 self-stretch relative text-lg font-body1-light z-[6]">
            Lorem ipsum dolor sit amet consectetur Convallis est
          </p>
        </div>
        <div className="flex flex-row items-start justify-end py-0 pr-[27px] pl-7">
          <button className="cursor-pointer [border:none] py-2.5 px-10 bg-color rounded-11xl flex flex-row items-start justify-start whitespace-nowrap z-[6] hover:bg-chocolate">
            <b className="relative text-3xl font-h6 text-txt text-left">
              Check Details
            </b>
          </button>
        </div>
      </div>
      <div className="h-[1818px] flex-1 relative max-w-full font-h6">
        <div className="absolute top-[569px] left-[-208px] [filter:blur(205.3px)] rounded-[50%] bg-gray-500 w-[358px] h-[358px]" />
        <img
          className="absolute top-[104px] left-[585px] w-[788px] h-[1160px] object-contain z-[2]"
          alt=""
          src="/image-11@2x.png"
        />
        <div className="absolute top-[86px] left-[1606px] [filter:blur(205.3px)] rounded-[50%] bg-gray-500 w-[358px] h-[358px] z-[2]" />
        <div className="absolute top-[1149px] left-[-192px] [filter:blur(205.3px)] rounded-[50%] bg-gray-400 w-[358px] h-[358px] z-[4]" />
        <div className="absolute top-[1002px] left-[0px] w-[1920px] h-[59px]">
          <img
            className="absolute top-[21px] left-[339px] w-[30px] h-[30px]"
            loading="lazy"
            alt=""
          />
          <div className="absolute top-[0px] left-[0px] bg-antiquewhite-400 w-full h-full z-[4]" />
        </div>
        <div className="absolute top-[0px] left-[1693px] [filter:blur(205.3px)] rounded-[50%] bg-gray-500 w-[358px] h-[358px] z-[3]" />
        <div className="absolute top-[1416px] left-[124px] w-[361.3px] h-[400px]">
          <div className="absolute top-[0px] left-[0px] w-full h-full">
            <img
              className="absolute top-[0px] left-[0px] w-full h-full object-cover"
              alt=""
              src="/mask-group-3@2x.png"
            />
            <img
              className="absolute top-[0px] left-[0px] w-full h-full object-cover"
              alt=""
              src="/mask-group-3@2x.png"
            />
            <img
              className="absolute top-[0px] left-[0px] w-full h-full"
              alt=""
              src="/mask-group-5.svg"
            />
          </div>
          <b className="absolute top-[87px] left-[111px] z-[8] mq450:text-3xl">
            Skin Color
          </b>
          <p className="m-0 absolute top-[144px] left-[39px] text-lg font-body1-light inline-block w-[283px] z-[8]">
            Lorem ipsum dolor sit amet consectetur Convallis est
          </p>
          <button className="cursor-pointer [border:none] py-2.5 px-10 bg-color absolute top-[279px] left-[67px] rounded-11xl flex flex-row items-start justify-start whitespace-nowrap z-[8] hover:bg-chocolate">
            <b className="relative text-3xl font-h6 text-txt text-left">
              Check Details
            </b>
          </button>
        </div>
        <div className="absolute top-[1418px] left-[561px] w-[361.3px] h-[400px]">
          <img
            className="absolute top-[0px] left-[0px] w-full h-full object-cover"
            alt=""
            src="/mask-group-6@2x.png"
          />
          <img
            className="absolute top-[0px] left-[0px] w-full h-full z-[5]"
            alt=""
            src="/mask-group-5.svg"
          />
        </div>
        <div className="absolute top-[1418px] left-[1435px] w-[361.3px] h-[400px]">
          <div className="absolute top-[0px] left-[0px] w-full h-full">
            <img
              className="absolute top-[0px] left-[0px] w-full h-full object-cover"
              alt=""
              src="/mask-group-8@2x.png"
            />
            <img
              className="absolute top-[0px] left-[0px] w-full h-full"
              alt=""
              src="/mask-group-5.svg"
            />
          </div>
          <b className="absolute top-[87px] left-[107.5px] z-[6] mq450:text-3xl">
            Undertone
          </b>
          <p className="m-0 absolute top-[144px] left-[39px] text-lg font-body1-light inline-block w-[283px] z-[6]">
            Lorem ipsum dolor sit amet consectetur Convallis est
          </p>
          <button className="cursor-pointer [border:none] py-2.5 px-10 bg-color absolute top-[277px] left-[67px] rounded-11xl flex flex-row items-start justify-start whitespace-nowrap z-[6] hover:bg-chocolate">
            <b className="relative text-3xl font-h6 text-txt text-left">
              Check Details
            </b>
          </button>
        </div>
      </div>
      <header className="w-[1195px] !m-[0] absolute top-[0px] left-[362px] flex flex-row items-start justify-center py-0 px-5 box-border max-w-full text-left text-11xl text-txt font-inter">
        <div className="w-[907px] flex flex-row items-start justify-between gap-[20px] max-w-full">
          <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
            <div className="self-stretch flex flex-row items-start justify-start">
              <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                Home
              </a>
            </div>
          </div>
          <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
            <div className="self-stretch flex flex-row items-start justify-start">
              <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                Shop
              </a>
            </div>
          </div>
          <div className="flex flex-row items-start justify-start text-center text-45xl font-le-murmure">
            <a className="[text-decoration:none] h-[72px] relative text-[inherit] inline-block whitespace-nowrap">
              stylescope
            </a>
          </div>
          <div className="flex flex-col items-start justify-start pt-[22px] px-0 pb-0">
            <div className="flex flex-row items-start justify-start">
              <a className="[text-decoration:none] relative leading-[28px] text-[inherit] inline-block min-w-[71px]">
                Scan
              </a>
            </div>
          </div>
          <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
            <div className="self-stretch flex flex-row items-start justify-start">
              <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                About
              </a>
            </div>
          </div>
        </div>
      </header>
    </div>
  );
};

export default RatingStars;
