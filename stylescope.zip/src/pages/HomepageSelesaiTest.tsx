import { FunctionComponent } from "react";
import RatingStars from "../components/RatingStars";
import OutfitRecommendationContaine from "../components/OutfitRecommendationContaine";

const HomepageSelesaiTest: FunctionComponentHomepageSelesaiTestType = () => {
  return (
    <div className="w-full relative bg-antiquewhite-200 overflow-hidden flex flex-col items-end justify-start pt-10 px-0 pb-[361px] box-border gap-[189px] leading-[normal] tracking-[normal] mq700:gap-[47px] mq975:gap-[94px]">
      <div className="self-stretch h-[1514px] relative bg-antiquewhite-200 hidden" />
      <section className="self-stretch flex flex-col items-start justify-start max-w-full">
        <RatingStars />
      </section>
      <OutfitRecommendationContaine />
    </div>
  );
};

export default HomepageSelesaiTest;
