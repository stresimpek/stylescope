import { FunctionComponent } from "react";
import FrameComponent2 from "../components/FrameComponent2";
import FrameComponent1 from "../components/FrameComponent1";
import FrameComponent from "../components/FrameComponent";

const LandingPage: FunctionComponentLandingPageType = () => {
  return (
    <div className="w-full relative bg-antiquewhite-200 overflow-hidden flex flex-col items-start justify-start pt-10 px-0 pb-0 box-border leading-[normal] tracking-[normal]">
      <img
        className="w-[30px] h-[30px] absolute !m-[0] top-[1063px] left-[339px]"
        loading="lazy"
        alt=""
      />
      <div className="self-stretch flex flex-row items-start justify-center pt-0 px-5 pb-[70px] box-border max-w-full">
        <header className="w-[1720px] flex flex-col items-end justify-start gap-[30px] max-w-full text-left text-11xl text-txt font-inter">
          <div className="self-stretch flex flex-row items-start justify-center py-0 pr-0 pl-px box-border max-w-full">
            <div className="w-[1195px] flex flex-row items-start justify-center py-0 px-5 box-border max-w-full mq925:gap-[21px] mq1350:gap-[43px]">
              <div className="w-[907px] flex flex-row items-start justify-between gap-[20px] max-w-full">
                <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
                  <div className="self-stretch flex flex-row items-start justify-start">
                    <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                      Home
                    </a>
                  </div>
                </div>
                <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
                  <div className="self-stretch flex flex-row items-start justify-start">
                    <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                      Shop
                    </a>
                  </div>
                </div>
                <div className="flex flex-row items-start justify-start text-center text-45xl font-le-murmure">
                  <a className="[text-decoration:none] h-[72px] relative text-[inherit] inline-block">
                    stylescope
                  </a>
                </div>
                <div className="flex flex-col items-start justify-start pt-[22px] px-0 pb-0">
                  <div className="flex flex-row items-start justify-start">
                    <a className="[text-decoration:none] relative leading-[28px] text-[inherit] inline-block min-w-[71px]">
                      Scan
                    </a>
                  </div>
                </div>
                <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
                  <div className="self-stretch flex flex-row items-start justify-start">
                    <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                      About
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="self-stretch h-px relative box-border border-t-[1px] border-solid border-txt" />
        </header>
      </div>
      <div className="w-[358px] h-[358px] absolute !m-[0] top-[126px] right-[-44px] [filter:blur(205.3px)] rounded-[50%] bg-gray-500 z-[1]" />
      <div className="w-[358px] h-[358px] absolute !m-[0] top-[609px] left-[-208px] [filter:blur(205.3px)] rounded-[50%] bg-gray-500 z-[1]" />
      <FrameComponent2 />
      <section className="self-stretch h-[129px] flex flex-row items-start justify-start pt-0 px-0 pb-[70px] box-border max-w-full">
        <div className="self-stretch flex-1 flex flex-row items-start justify-start max-w-full z-[3]">
          <div className="self-stretch flex-1 relative bg-antiquewhite-300 max-w-full" />
        </div>
      </section>
      <FrameComponent1 />
      <FrameComponent />
      <section className="self-stretch flex flex-row items-start justify-start py-0 pr-[227px] pl-[298px] box-border gap-[83px] max-w-full text-center text-[40px] text-gray-300 font-body1-light mq450:gap-[21px] mq450:pl-5 mq450:pr-5 mq450:box-border mq925:gap-[41px] mq925:pl-[74px] mq925:pr-14 mq925:box-border mq1350:pl-[149px] mq1350:pr-[113px] mq1350:box-border mq1825:flex-wrap">
        <div className="ml-[-441px] h-[672px] w-[358px] flex flex-col items-start justify-start pt-[314px] px-0 pb-0 box-border max-w-full shrink-0 mq925:pt-[204px] mq925:box-border">
          <div className="self-stretch flex-1 relative [filter:blur(205.3px)] rounded-[50%] bg-gray-500 shrink-0 [debug_commit:bf4bc93]" />
        </div>
        <p className="m-0 w-[1395px] relative tracking-[1px] leading-[60px] inline-block shrink-0 [debug_commit:bf4bc93] max-w-full mq450:text-5xl mq450:leading-[36px] mq925:text-13xl mq925:leading-[48px]">
          Welcome to StyleScope, your ultimate fashion companion! StyleScope is
          a cutting-edge application designed to revolutionize the way you
          approach fashion and personal style. Our advanced scanning technology
          analyzes your unique physical features to provide personalized fashion
          recommendations that enhance your natural beauty and suit your
          individual preferences.
        </p>
      </section>
    </div>
  );
};

export default LandingPage;
