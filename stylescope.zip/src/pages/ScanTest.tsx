import { FunctionComponent } from "react";
import FrameComponent4 from "../components/FrameComponent4";
import FrameComponent3 from "../components/FrameComponent3";

const ScanTest: FunctionComponentScanTestType = () => {
  return (
    <div className="w-full relative bg-antiquewhite-200 overflow-hidden flex flex-col items-end justify-start pt-[41px] pb-[49px] pr-[99px] pl-[100px] box-border gap-[22.3px] leading-[normal] tracking-[normal] lg:pl-[50px] lg:pr-[49px] lg:box-border mq825:pl-[25px] mq825:pr-6 mq825:box-border">
      <div className="w-[358px] h-[358px] absolute !m-[0] top-[-122px] right-[-79px] [filter:blur(205.3px)] rounded-[50%] bg-gray-400" />
      <header className="self-stretch flex flex-row items-start justify-center pt-0 pb-[6.7px] pr-px pl-0 box-border max-w-full text-left text-11xl text-txt font-inter">
        <div className="w-[1195px] flex flex-row items-start justify-center py-0 px-5 box-border max-w-full lg:gap-[43px] mq825:gap-[21px]">
          <div className="w-[907px] flex flex-row items-start justify-between gap-[20px] max-w-full">
            <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
              <div className="self-stretch flex flex-row items-start justify-start">
                <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                  Home
                </a>
              </div>
            </div>
            <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
              <div className="self-stretch flex flex-row items-start justify-start">
                <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                  Shop
                </a>
              </div>
            </div>
            <div className="flex flex-row items-start justify-start text-center text-45xl font-le-murmure">
              <a className="[text-decoration:none] h-[72px] relative text-[inherit] inline-block whitespace-nowrap">
                stylescope
              </a>
            </div>
            <div className="flex flex-col items-start justify-start pt-[22px] px-0 pb-0">
              <div className="flex flex-row items-start justify-start">
                <a className="[text-decoration:none] relative leading-[28px] text-[inherit] inline-block min-w-[71px]">
                  Scan
                </a>
              </div>
            </div>
            <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
              <div className="self-stretch flex flex-row items-start justify-start">
                <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                  About
                </a>
              </div>
            </div>
          </div>
        </div>
      </header>
      <div className="self-stretch h-px relative box-border z-[1] border-t-[1px] border-solid border-txt" />
      <main className="w-[1685px] flex flex-row items-start justify-end py-0 px-1.5 box-border max-w-full">
        <section className="flex-1 flex flex-col items-start justify-start gap-[30.7px] max-w-full text-center text-181xl text-txt font-le-murmure mq825:gap-[15px]">
          <div className="w-[1317px] flex flex-row items-start justify-start relative max-w-full">
            <div className="h-[358px] w-[358px] absolute !m-[0] bottom-[-152.33px] left-[-298px] [filter:blur(205.3px)] rounded-[50%] bg-gray-400 z-[2]" />
            <div className="flex-1 flex flex-row items-start justify-end max-w-full">
              <div className="flex flex-row items-end justify-start gap-[67px] max-w-full lg:flex-wrap lg:gap-[33px] mq825:gap-[17px]">
                <div className="h-[133.6px] w-[132px] flex flex-col items-start justify-end pt-0 px-0 pb-[9.6px] box-border">
                  <img
                    className="self-stretch flex-1 relative max-w-full overflow-hidden max-h-full"
                    loading="lazy"
                    alt=""
                    src="/starfilledwide-2.svg"
                  />
                </div>
                <div className="flex flex-row items-start justify-start gap-[33px] max-w-full lg:flex-wrap mq450:gap-[16px]">
                  <div className="flex flex-row items-start justify-start [row-gap:20px] max-w-full mq825:flex-wrap">
                    <h1 className="m-0 h-[211.4px] w-[389px] relative text-inherit font-normal font-inherit whitespace-pre-wrap inline-block min-w-[389px] max-w-full mq825:text-61xl mq825:flex-1 mq825:min-w-full mq450:text-31xl">{`feature   `}</h1>
                    <div className="w-[237px] flex flex-col items-start justify-start pt-[28.8px] px-0 pb-0 box-border min-w-[237px] text-[transparent] mq825:flex-1">
                      <h1 className="m-0 self-stretch h-[182.5px] relative text-inherit font-normal font-inherit inline-block [-webkit-text-stroke:3px_#fff] mq825:text-61xl mq450:text-31xl">
                        scan
                      </h1>
                    </div>
                  </div>
                  <div className="h-[139.7px] w-[132px] flex flex-col items-start justify-start pt-[15.7px] px-0 pb-0 box-border">
                    <img
                      className="self-stretch flex-1 relative max-w-full overflow-hidden max-h-full"
                      loading="lazy"
                      alt=""
                      src="/starfilledwide-2.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <FrameComponent4 />
          <FrameComponent3 />
        </section>
      </main>
    </div>
  );
};

export default ScanTest;
