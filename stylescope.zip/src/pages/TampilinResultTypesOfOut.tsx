import { FunctionComponent } from "react";
import FrameComponent8 from "../components/FrameComponent8";
import FrameComponent7 from "../components/FrameComponent7";
import FrameComponent6 from "../components/FrameComponent6";

const TampilinResultTypesOfOut: FunctionComponentTampilinResultTypesOfOutType =
  () => {
    return (
      <div className="w-full relative bg-antiquewhite-200 overflow-hidden flex flex-col items-start justify-start pt-11 px-0 pb-[339px] box-border gap-[24px] leading-[normal] tracking-[normal]">
        <div className="w-[358px] h-[358px] absolute !m-[0] top-[-122px] right-[-79px] [filter:blur(205.3px)] rounded-[50%] bg-gray-400" />
        <header className="self-stretch flex flex-row items-start justify-center pt-0 px-5 pb-1 box-border max-w-full text-left text-11xl text-txt font-inter">
          <div className="w-[1720px] flex flex-col items-start justify-start gap-[26px] max-w-full">
            <div className="w-[1701px] flex flex-row items-start justify-center max-w-full">
              <div className="w-[1195px] flex flex-row items-start justify-center py-0 px-5 box-border max-w-full mq950:gap-[21px] mq1425:gap-[43px]">
                <div className="w-[907px] flex flex-row items-start justify-between gap-[20px] max-w-full">
                  <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
                    <div className="self-stretch flex flex-row items-start justify-start">
                      <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                        Home
                      </a>
                    </div>
                  </div>
                  <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
                    <div className="self-stretch flex flex-row items-start justify-start">
                      <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                        Shop
                      </a>
                    </div>
                  </div>
                  <div className="flex flex-row items-start justify-start text-center text-45xl font-le-murmure">
                    <a className="[text-decoration:none] h-[72px] relative text-[inherit] inline-block whitespace-nowrap">
                      stylescope
                    </a>
                  </div>
                  <div className="flex flex-col items-start justify-start pt-[22px] px-0 pb-0">
                    <div className="flex flex-row items-start justify-start">
                      <a className="[text-decoration:none] relative leading-[28px] text-[inherit] inline-block min-w-[71px]">
                        Scan
                      </a>
                    </div>
                  </div>
                  <div className="w-[104px] flex flex-col items-start justify-start pt-[22px] px-0 pb-0 box-border">
                    <div className="self-stretch flex flex-row items-start justify-start">
                      <a className="[text-decoration:none] flex-1 relative leading-[28px] text-[inherit]">
                        About
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="self-stretch h-px relative box-border z-[1] border-t-[1px] border-solid border-txt" />
          </div>
        </header>
        <FrameComponent8 />
        <section className="w-[1889px] flex flex-row items-start justify-center pt-0 px-5 pb-[67px] box-border max-w-full text-left text-15xl text-txt font-body1-light mq950:pb-11 mq950:box-border">
          <div className="w-[1157px] flex flex-row items-start justify-start gap-[127px] max-w-full mq450:gap-[16px] mq950:gap-[32px] mq1425:flex-wrap mq1425:gap-[63px]">
            <div className="flex-1 flex flex-col items-start justify-start pt-[26px] px-0 pb-0 box-border min-w-[348px] max-w-full mq450:min-w-full">
              <div className="self-stretch flex flex-col items-start justify-start gap-[55.3px] max-w-full mq950:gap-[28px]">
                <div className="w-[418px] h-[29px] relative font-medium inline-block shrink-0 max-w-full mq450:text-xl mq950:text-8xl">
                  Your skin color is Beige
                </div>
                <p className="m-0 self-stretch h-[100.7px] relative text-xl inline-block shrink-0 mq450:text-base">
                  <span className="block">
                    <span>Recommended :</span>
                  </span>
                  <span className="block">
                    <span>
                      Neutral colors like light brown and grey, terracotta,
                      olive green, orange, deep blue, peach, soft yellow, and
                      navy blue.
                    </span>
                  </span>
                  <span className="block">
                    <span>&nbsp;</span>
                  </span>
                  <span className="block">
                    <span>Avoid:</span>
                  </span>
                  <span className="block">
                    <span>
                      Neon colors too bright, overly pale shades, excessively
                      bright and vivid colors, overly dark shades.
                    </span>
                  </span>
                </p>
              </div>
            </div>
            <img
              className="w-[494px] relative max-h-full object-cover max-w-full mq1425:flex-1"
              loading="lazy"
              alt=""
              src="/mask-group@2x.png"
            />
          </div>
        </section>
        <FrameComponent7 />
        <FrameComponent6 />
      </div>
    );
  };

export default TampilinResultTypesOfOut;
