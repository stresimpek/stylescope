/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        antiquewhite: {
          "100": "#f0e3d2",
          "200": "#d9c7b3",
          "300": "rgba(240, 227, 210, 0.5)",
          "400": "rgba(240, 227, 210, 0.4)",
        },
        gray: {
          "100": "#7f7f7f",
          "200": "#191919",
          "300": "rgba(255, 255, 255, 0.8)",
          "400": "rgba(255, 255, 255, 0.6)",
          "500": "rgba(255, 255, 255, 0.7)",
        },
        txt: "#fff",
        color: "#ec744a",
        chocolate: "#d45c30",
        tan: {
          "100": "#d3b9a0",
          "200": "#caab8c",
        },
      },
      spacing: {},
      fontFamily: {
        "body1-light": "Poppins",
        "le-murmure": "'Le Murmure'",
        inter: "Inter",
        h6: "Manrope",
        inherit: "inherit",
      },
      borderRadius: {
        xl: "20px",
        "11xl": "30px",
        "7xs-1": "5.1px",
      },
    },
    fontSize: {
      "5xl": "24px",
      lgi: "19px",
      "13xl": "32px",
      "7xl": "26px",
      "181xl": "200px",
      "61xl": "80px",
      "31xl": "50px",
      "11xl": "30px",
      "45xl": "64px",
      "3xl": "22px",
      lg: "18px",
      "9xl": "28px",
      "211xl": "230px",
      "73xl": "92px",
      "38xl": "57px",
      "481xl": "500px",
      "106xl": "125px",
      "231xl": "250px",
      "43xl": "62px",
      "81xl": "100px",
      mid: "17px",
      xl: "20px",
      base: "16px",
      "15xl": "34px",
      "8xl": "27px",
      inherit: "inherit",
    },
    screens: {
      mq1900: {
        raw: "screen and (max-width: 1900px)",
      },
      mq1825: {
        raw: "screen and (max-width: 1825px)",
      },
      mq1425: {
        raw: "screen and (max-width: 1425px)",
      },
      mq1400: {
        raw: "screen and (max-width: 1400px)",
      },
      mq1350: {
        raw: "screen and (max-width: 1350px)",
      },
      lg: {
        max: "1200px",
      },
      mq975: {
        raw: "screen and (max-width: 975px)",
      },
      mq950: {
        raw: "screen and (max-width: 950px)",
      },
      mq925: {
        raw: "screen and (max-width: 925px)",
      },
      mq825: {
        raw: "screen and (max-width: 825px)",
      },
      mq700: {
        raw: "screen and (max-width: 700px)",
      },
      mq450: {
        raw: "screen and (max-width: 450px)",
      },
    },
  },
  corePlugins: {
    preflight: false,
  },
};
